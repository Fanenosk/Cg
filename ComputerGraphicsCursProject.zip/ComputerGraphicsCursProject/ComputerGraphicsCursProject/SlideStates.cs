﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerGraphicsCursProject
{
    public class SlideStates
    {
        public double X;
        public double Y;
        public double Z;
        public SlideStates()
        {
            X = 0;
            Y = 0;
            Z = 0;
        }
    }
}
